const DEFAULTS = {
  whatsapp: "2340000000000",
  phone: "+234 000 000 0000",
  email: "info@grainespreciousacademy.com",
  announcements: [
    {tag:"School News", title:"Welcome to the 2026/2027 Session", text:"Welcome students and parents. Check this portal regularly for important school updates.", date:"September 2026"},
    {tag:"Registration", title:"Student Registration is Open", text:"New students can complete the online application and contact the administrator on WhatsApp.", date:"September 2026"},
    {tag:"Event", title:"School Activities & Events", text:"Watch the notice board for upcoming academic, sports and cultural activities.", date:"2026/2027 Session"}
  ],
  timetable: {
    "JSS 1":[["8:00 – 8:40","Mathematics","English","Basic Science","Mathematics","English"],["8:40 – 9:20","English","Basic Technology","Mathematics","Social Studies","Basic Science"],["9:20 – 10:00","Basic Science","Mathematics","English","Computer","Social Studies"],["10:30 – 11:10","Computer","Social Studies","PHE","English","Mathematics"],["11:10 – 11:50","PHE","Civic Education","Computer","Basic Science","French"]],
    "JSS 2":[["8:00 – 8:40","English","Mathematics","Basic Science","English","Mathematics"],["8:40 – 9:20","Mathematics","Computer","English","Basic Technology","Basic Science"],["9:20 – 10:00","Basic Science","English","Mathematics","Social Studies","Computer"],["10:30 – 11:10","Civic Education","PHE","Computer","Mathematics","English"],["11:10 – 11:50","French","Basic Technology","PHE","Basic Science","Social Studies"]],
    "JSS 3":[["8:00 – 8:40","Mathematics","English","Mathematics","English","Basic Science"],["8:40 – 9:20","English","Basic Science","Computer","Mathematics","Social Studies"],["9:20 – 10:00","Basic Science","Mathematics","English","Computer","Civic Education"],["10:30 – 11:10","Computer","PHE","Social Studies","Basic Science","Mathematics"],["11:10 – 11:50","Civic Education","French","PHE","English","Computer"]],
    "SS 1":[["8:00 – 8:40","Mathematics","English","Physics","Mathematics","Chemistry"],["8:40 – 9:20","English","Chemistry","Mathematics","Biology","English"],["9:20 – 10:00","Physics","Mathematics","Biology","Economics","Government"],["10:30 – 11:10","Biology","Economics","Chemistry","English","Mathematics"],["11:10 – 11:50","Government","Physics","Computer","Chemistry","Biology"]],
    "SS 2":[["8:00 – 8:40","Mathematics","English","Chemistry","Mathematics","Physics"],["8:40 – 9:20","English","Biology","Mathematics","Chemistry","English"],["9:20 – 10:00","Physics","Mathematics","Biology","Economics","Government"],["10:30 – 11:10","Biology","Economics","Chemistry","English","Mathematics"],["11:10 – 11:50","Government","Physics","Computer","Biology","Chemistry"]],
    "SS 3":[["8:00 – 8:40","Mathematics","English","Chemistry","Mathematics","Physics"],["8:40 – 9:20","English","Biology","Mathematics","Chemistry","English"],["9:20 – 10:00","Physics","Mathematics","Biology","Economics","Government"],["10:30 – 11:10","Biology","Economics","Chemistry","English","Mathematics"],["11:10 – 11:50","Government","Physics","Computer","Biology","Chemistry"]]
  }
};

function getData(){
  const saved = JSON.parse(localStorage.getItem("gpaData") || "null");
  return saved ? {...DEFAULTS,...saved,timetable:{...DEFAULTS.timetable,...(saved.timetable||{})}} : DEFAULTS;
}
function saveData(data){ localStorage.setItem("gpaData", JSON.stringify(data)); }

function setupContact(){
  const d=getData();
  const wa=`https://wa.me/${d.whatsapp}?text=${encodeURIComponent("Hello Graines Precious Academy Admin, I would like to register a student.")}`;
  document.getElementById("whatsappRegister").href=wa;
  document.getElementById("adminWhatsapp").href=wa;
  document.getElementById("schoolPhoneText").textContent=d.phone;
  document.getElementById("callLink").href=`tel:${d.phone.replace(/\s/g,"")}`;
  document.getElementById("schoolEmailText").textContent=d.email;
  document.getElementById("emailLink").href=`mailto:${d.email}`;
}
function renderAnnouncements(){
  const items=getData().announcements;
  document.getElementById("announcementGrid").innerHTML=items.map(x=>`
    <article class="announcement"><span class="tag">${x.tag}</span><h3>${x.title}</h3><p>${x.text}</p><small>${x.date}</small></article>`).join("");
}
let selectedClass="JSS 1";
function renderTimetable(){
  const data=getData().timetable;
  const tabs=document.getElementById("classTabs");
  tabs.innerHTML=Object.keys(data).map(c=>`<button class="${c===selectedClass?"active":""}" data-class="${c}">${c}</button>`).join("");
  tabs.querySelectorAll("button").forEach(b=>b.onclick=()=>{selectedClass=b.dataset.class;renderTimetable();});
  document.getElementById("timetableBody").innerHTML=(data[selectedClass]||[]).map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join("")}</tr>`).join("");
}
function updateClock(){
  document.getElementById("liveDate").textContent=new Intl.DateTimeFormat("en-NG",{dateStyle:"medium",timeStyle:"short"}).format(new Date());
  document.getElementById("year").textContent=new Date().getFullYear();
}
document.getElementById("menuBtn").onclick=()=>document.getElementById("mainNav").classList.toggle("open");
document.querySelectorAll("#mainNav a").forEach(a=>a.onclick=()=>document.getElementById("mainNav").classList.remove("open"));

document.getElementById("registrationForm").addEventListener("submit",e=>{
  e.preventDefault();
  const data=Object.fromEntries(new FormData(e.target).entries());
  const list=JSON.parse(localStorage.getItem("gpaApplications")||"[]");
  data.id="GPA-"+Date.now().toString().slice(-7);
  data.submittedAt=new Date().toISOString();
  list.push(data);
  localStorage.setItem("gpaApplications",JSON.stringify(list));
  const msg=document.getElementById("formMessage");
  msg.hidden=false;
  msg.textContent=`Application submitted successfully. Application ID: ${data.id}. Please contact the administrator on WhatsApp to continue.`;
  e.target.reset();
});

setupContact();renderAnnouncements();renderTimetable();updateClock();setInterval(updateClock,30000);
