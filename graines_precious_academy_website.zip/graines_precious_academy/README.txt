# Graines Precious Academy School Portal

## Included
- `index.html` — public school website
- `admin.html` — browser-based admin dashboard
- `style.css` — responsive modern design
- `script.js` — timetable, announcements, registration and contact logic
- `assets/school-logo.jpg` — the school logo supplied in the chat

## IMPORTANT: set the real WhatsApp number
Open `admin.html`, sign in, then go to **Settings** and enter the administrator's WhatsApp number in international format without `+` or spaces.

Example:
`2348012345678`

## Demo admin login
- Admin ID: `admin`
- Password: `admin123`

Change this before publishing a real school system. This demo admin login is client-side and is NOT secure enough for sensitive production data.

## How to run
1. Extract the ZIP.
2. Open `index.html` in a browser.
3. Open `admin.html` to manage demo data.
4. For hosting, upload the whole folder to Netlify, GitHub Pages (static parts), Vercel, or another static host.

## Important production note
The current version is a fully working static prototype. Student registrations and admin edits are stored in the browser's localStorage, so they do not automatically appear on another phone/computer.

For a real school-wide system with secure accounts, shared student records, teacher accounts, database storage, password hashing, file uploads and multi-device synchronization, connect the same interface to a backend such as Supabase/Firebase or a custom Node/PHP/MySQL server.
